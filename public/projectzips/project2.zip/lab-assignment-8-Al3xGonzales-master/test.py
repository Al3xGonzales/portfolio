import unittest
from main import *

class TestLabFunctions(unittest.TestCase):
    def test_calculate_circle_area(self):
        self.assertAlmostEqual(calculate_circle_area(5), 78.53981633974483)

    def test_calculate_square_root(self):
        self.assertAlmostEqual(calculate_square_root(16), 4)

    def test_calculate_mean_median(self):
        self.assertEqual(calculate_mean_median([1, 2, 3, 4, 5]), (3.0, 3))

    def test_demonstrate_random_module(self):
        choice, sample, random_num = demonstrate_random_module()
        self.assertIn(choice, ['apple', 'banana', 'orange', 'grape'])
        self.assertEqual(len(sample), 5)
        self.assertTrue(random_num >= 1 and random_num <= 100)

    # Add more test cases for other functions

if __name__ == "__main__":
    unittest.main()
