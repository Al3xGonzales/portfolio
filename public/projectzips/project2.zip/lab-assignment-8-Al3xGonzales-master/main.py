import math
import statistics
import random
import datetime
import reprlib
import pprint
import textwrap
import threading

# Function to calculate area of a circle
def calculate_circle_area(radius):
    """
    Calculate the area of a circle with given radius.

    Args:
        radius (float): The radius of the circle.

    Returns:
        float: The area of the circle.
    """
    # ADD YOUR CODE BELOW!
    return math.pi * radius ** 2

# Function to calculate square root
def calculate_square_root(number):
    """
    Calculate the square root of a given number.

    Args:
        number (float): The number whose square root is to be calculated.

    Returns:
        float: The square root of the given number.
    """
    # ADD YOUR CODE BELOW!
    return math.sqrt(number)

# Function to calculate mean and median
def calculate_mean_median(data):
    """
    Calculate the mean and median of a list of numbers.

    Args:
        data (list): A list of numbers.

    Returns:
        tuple: A tuple containing the mean and median of the input data.
    """
    # ADD YOUR CODE BELOW!
    mean = sum(data) / len(data)
    dataSort= sorted(data)
    lenSort = len(dataSort)
    if lenSort % 2 == 0:
        med = (dataSort[lenSort // 2 - 1] + dataSort[lenSort // 2]) / 2
    else:
        med = dataSort[lenSort // 2]

    return mean, med

# Function to demonstrate random module
def demonstrate_random_module():
    """
    Demonstrate various functionalities of the random module.

    Returns:
        tuple: A tuple containing a random choice, a random sample, and a random number.
    """
    # ADD YOUR CODE BELOW!
    ranC = random.choice(["apple", "banana", "cherry"])
    ranS = random.sample(range(1, 100), 5)
    ran = random.randint(1, 100)
    return ranC, ranS, ran

# Function to display current date and time
def display_current_datetime():
    """
    Display the current date and time.

    Returns:
        datetime: The current date and time.
    """
    # ADD YOUR CODE BELOW!
    return datetime.datetime.now()

# Function to demonstrate reprlib
def demonstrate_reprlib(data):
    """
    Demonstrate the use of reprlib to represent large data structures.

    Args:
        data: The data structure to be represented.

    Returns:
        str: The truncated representation of the input data.
    """
    # ADD YOUR CODE BELOW!
    return reprlib.repr(data)

# Function to demonstrate pprint
def demonstrate_pprint(data):
    """
    Demonstrate the use of pprint to pretty-print data structures.

    Args:
        data: The data structure to be pretty-printed.
    """
    # ADD YOUR CODE BELOW!
    pprint.pprint(data)

# Function to demonstrate textwrap
def demonstrate_textwrap(string, width):
    """
    Demonstrate the use of textwrap to wrap long strings to a specified width.

    Args:
        string (str): The input string to be wrapped.
        width (int): The width at which the string should be wrapped.

    Returns:
        str: The wrapped string.
    """
    # ADD YOUR CODE BELOW!
    return textwrap.fill(string, width)

# Function for multithreading
def thread_task():
    """
    Perform a simple task in a thread.

    This function is used to demonstrate multithreading.
    """
    # ADD YOUR CODE BELOW!
    print(f"{threading.current_thread().name} is running")

if __name__ == "__main__":
    # Test cases for each functionality
    radius = 5
    number = 16
    data = [3, 5, 2, 7, 9, 4, 6, 1, 8, 10]
    string = "This is a long string that needs to be wrapped to a specified width."
    width = 20

    print("1. Calculating area of circle with radius:", radius)
    print("Area:", calculate_circle_area(radius))

    print("\n2. Calculating square root of number:", number)
    print("Square root:", calculate_square_root(number))

    print("\n3. Calculating mean and median of data:", data)
    mean, median = calculate_mean_median(data)
    print("Mean:", mean)
    print("Median:", median)

    print("\n4. Demonstrating random module:")
    choice, sample, random_num = demonstrate_random_module()
    print("Random choice:", choice)
    print("Random sample:", sample)
    print("Random number:", random_num)

    print("\n5. Displaying current date and time:")
    print("Current date and time:", display_current_datetime())

    print("\n6. Demonstrating reprlib:")
    large_list = list(range(1000))
    print("Truncated representation of large list:", demonstrate_reprlib(large_list))

    print("\n7. Demonstrating pprint:")
    nested_dict = {'a': 1, 'b': {'c': 2, 'd': {'e': 3, 'f': 4}}}
    print("Pretty-printing nested dictionary:")
    demonstrate_pprint(nested_dict)

    print("\n8. Demonstrating textwrap:")
    print("Wrapped string:")
    print(demonstrate_textwrap(string, width))

    print("\n9. Demonstrating multithreading:")
    thread1 = threading.Thread(target=thread_task, name='Thread 1')
    thread2 = threading.Thread(target=thread_task, name='Thread 2')

    thread1.start()
    thread2.start()

    thread1.join()
    thread2.join()
