[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/Of8tytk3)
# Laboratory 8

## Laboratory Objectives
1. Explore and use various tools such as: VSCode, Command Prompt, and Github.
1. Write a Python program using the Python Standard Libraries that we discussed in the last 2 sessions.
1. Run and test a Python program.

## Getting Started
1. Open the Terminal program in VSCode or Command Prompt in your systems.
1. Change the present working directory to the `Documents` directory by typing the following command at the command prompt:

    ```
    cd Documents
    ```

1. Make a copy of this Github repository on your computer using the `git` and `clone` commands that you will input to the terminal. The commands take a URL as a parameter to specify where it can get a copy of the repository. You can find the URL by clicking on the green *Clone or download* button at the top right part of this page. Copy the URL and replace the example text shown below. Note that `username` should be replaced with your own Github username. When you hit <kbd>Enter</kbd> it will ask you to provide your Github username and token. Once done, you will have a copy of the repository on your computer.
    ```
    git clone https://github.com/CSUF-CPSC223P-NILAYJAIN12/Lab-8.git
    ```
1. Navigate into the new directory using the command line. Note that `username` should be replaced with your own Github username.  As a shortcut, you can type the first few letters of the folder name and press <kbd>Tab</kbd> so that it auto completes the folder name for you.

     ```
     cd lab04-username
     ```
## Objective
The objective of this lab assignment is to explore various Python modules and understand the concept of multithreading.
   
## Program Instructions
In this lab assignment, you are required to write a Python script that demonstrates the usage of various modules and techniques. Your script should include the following functionalities:
1. Math Module:
     - Calculate the area of a circle with radius r, using the value of pi from the math module.
     - Calculate the square root of a given number.

1. Statistics Module:
     - Calculate the mean and median of a list of numbers using the statistics module.

1. Random Module:
     - Generate a random choice from a given list.
     - Generate a random sample of n elements from a population.
     - Generate a random number between a specified range.

1. Datetime Module:
     - Display the current date and time using the datetime module.

1. Reprlib:
     - Use reprlib to represent a large list in a truncated form.

1. Pprint:
     - Use pprint to pretty-print a dictionary with nested structures.

1. Textwrap:
     - Use textwrap to wrap a long string to a specified width.

1. Multithreading:
     - Demonstrate the concept of multithreading by performing a simple task concurrently in multiple threads.

1. Run the unit testing program ```test.py``` to ensure that your program runs as expected.

    ```
    Run the test.py file directly or using the command in the terminal "python test.py"
    ```

## Submission
Periodically throughout the exercise, and when you have completed the exercise, **submit the complete repository to Github**.

   <pre>git add .<br>git commit -m "<i>your comment</i>"<br>git push</pre>

In case it asks you  to configure global variables for an email and name, just copy the commands it provides then replace the dummy text with your email and Github token.

   <pre>git config --global user.email "<i>tuffy@csu.fullerton.edu</i>"<br>git config --global user.name "<i>Tuffy Titan</i>"<br>git commit -m "<i>your comment</i>"<br>git push</pre>

When you completed the final Github push, go back into github.com through the browser interface and ensure all your files have been correctly updated.  You should have the following files:
```
main.py [With your complete code!]
```
    
## Grading
1. All points add up to a total of 100 points possible as detailed below.  Partial credit will be given where applicable.

| Points | Description |
| --- | --- |
|50|initial git clone of this repository to your machine|
|35|main.py file submitted contains the main driver program and meets the program requirements|
|15|If the unit test case file passed|
