/* Andres Gallego 
CWID: 889001145
andresgallego@csu.fullerton.edu */

document.addEventListener("DOMContentLoaded", function () {
  document
    .querySelector("#login form")
    .addEventListener("submit", function (event) {
      event.preventDefault();

      const username = document.getElementById("loginUser").value;
      const password = document.getElementById("loginPassword").value;

      // Retrieve stored users
      const users = JSON.parse(localStorage.getItem("users")) || [];

      // Verify credentials
      const userExists = users.some(
        (user) => user.username === username && user.password === password
      );

      if (userExists) {
        // Redirect to dashboard or show success message
        window.location.href = "dashboard.html";
      } else {
        // Optional: update the UI to reflect an unsuccessful login attempt
        alert("Invalid credentials. Please try again or register.");
      }
    });
});
