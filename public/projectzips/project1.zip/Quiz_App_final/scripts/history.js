/* Andres Gallego 
CWID: 889001145
andresgallego@csu.fullerton.edu */

document.addEventListener("DOMContentLoaded", function () {
  const submitButton = document.querySelector("#submit-questions");
  const resetButton = document.querySelector("#reset-page");

  // Define the question bank
  const questionBank = [
    {
      question: "Who was the first President of the US?",
      options: [
        "Thomas Jefferson",
        "John Adams",
        "George Washington",
        "Abraham Lincoln",
      ],
      answer: "George Washington",
    },
    {
      question: "What ancient civilization built the pyramids?",
      options: [
        "Ancient Greece",
        "Ancient Rome",
        "Ancient Egypt",
        "Mesopotamia",
      ],
      answer: "Ancient Egypt",
    },
    {
      question: "During which years did World War II take place?",
      options: ["1914-1918", "1939-1945", "1941-1945", "1950-1953"],
      answer: "1939-1945",
    },
    {
      question: "Who wrote the Declaration of Independence?",
      options: [
        "George Washington",
        "Benjamin Franklin",
        "Thomas Jefferson",
        "John Adams",
      ],
      answer: "Thomas Jefferson",
    },
    {
      question: "Which empire was ruled by Alexander the Great?",
      options: [
        "Roman Empire",
        "Macedonian Empire",
        "Persian Empire",
        "Byzantine Empire",
      ],
      answer: "Macedonian Empire",
    },

    {
      question: "Who was the first Emperor of Rome?",
      options: ["Julius Caesar", "Augustus", "Nero", "Constantine the Great"],
      answer: "Augustus",
    },
    {
      question:
        "Which battle is considered the turning point of the American Civil War?",
      options: [
        "Battle of Gettysburg",
        "Battle of Antietam",
        "Battle of Vicksburg",
        "Battle of Bull Run",
      ],
      answer: "Battle of Gettysburg",
    },
    {
      question: "Who was the longest-reigning monarch in British history?",
      options: [
        "Queen Victoria",
        "King Henry VIII",
        "King George III",
        "Queen Elizabeth II",
      ],
      answer: "Queen Victoria",
    },
    {
      question: "Which city was the capital of the Byzantine Empire?",
      options: ["Athens", "Rome", "Constantinople", "Alexandria"],
      answer: "Constantinople",
    },
    {
      question: "Who was the founder of the Mongol Empire?",
      options: ["Genghis Khan", "Kublai Khan", "Timur", "Attila the Hun"],
      answer: "Genghis Khan",
    },
    {
      question:
        "Which civilization developed the first known system of writing?",
      options: [
        "Ancient Egyptians",
        "Ancient Sumerians",
        "Ancient Greeks",
        "Ancient Romans",
      ],
      answer: "Ancient Sumerians",
    },
    {
      question: "Who was the first European explorer to reach India by sea?",
      options: [
        "Vasco da Gama",
        "Christopher Columbus",
        "Ferdinand Magellan",
        "Marco Polo",
      ],
      answer: "Vasco da Gama",
    },
    {
      question: "Which ancient city was known as the 'City of Seven Hills'?",
      options: ["Rome", "Athens", "Jerusalem", "Babylon"],
      answer: "Rome",
    },
    {
      question: "Which war is often referred to as the 'War to End All Wars'?",
      options: [
        "World War I",
        "American Civil War",
        "Napoleonic Wars",
        "Vietnam War",
      ],
      answer: "World War I",
    },
    {
      question: "Who was the last pharaoh of ancient Egypt?",
      options: ["Cleopatra VII", "Ramesses II", "Hatshepsut", "Tutankhamun"],
      answer: "Cleopatra VII",
    },
    // Add more questions as needed
  ];

  let correctAnswers = {}; // This will be dynamically filled based on generated questions

  generateQuestions(); // Initial question generation

  submitButton.addEventListener("click", function (event) {
    event.preventDefault();
    if (!allQuestionsAnswered()) {
      alert("Please answer all questions before submitting.");
      return;
    }

    calculateScoreAndProvideFeedback();
  });

  resetButton.addEventListener("click", function (event) {
    event.preventDefault();
    resetQuiz();
    generateQuestions(); // Regenerate questions on reset
  });

  function allQuestionsAnswered() {
    return Object.keys(correctAnswers).every(function (question) {
      return (
        document.querySelector(`input[name="${question}"]:checked`) !== null
      );
    });
  }

  function calculateScoreAndProvideFeedback() {
    let historyScore = 0;
    Object.keys(correctAnswers).forEach(function (question) {
      const selectedAnswerElement = document.querySelector(
        `input[name="${question}"]:checked`
      );
      const listItem = selectedAnswerElement.closest("li"); // Get the closest list item
      const isCorrect =
        selectedAnswerElement.value === correctAnswers[question];

      if (isCorrect) {
        historyScore++;
        listItem.classList.add("correct"); // Adds 'correct' class to the list item
      } else {
        listItem.classList.add("incorrect"); // Adds 'incorrect' class to the list item
      }
    });

    localStorage.setItem("historyScore", historyScore);
    window.globalFinalGrade_History = historyScore;

    alert(
      `Your score is ${historyScore} out of ${Object.keys(correctAnswers).length}`
    );
  }

  function resetQuiz() {
    document.querySelectorAll('input[type="radio"]').forEach(function (radio) {
      radio.checked = false;
      radio.parentNode.classList.remove("correct", "incorrect");
    });
    localStorage.setItem("historyScore", 0);
    window.globalFinalGrade_History = 0;
  }

  // Generates a specified number of random questions and displays them
  function generateQuestions() {
    const selectedQuestions = selectRandomQuestions(questionBank, 5); // Adjust the number as necessary
    displayQuestions(selectedQuestions);
  }

  // Selects N random questions from the bank
  function selectRandomQuestions(bank, number) {
    let selected = [];
    let indices = [];
    while (selected.length < number) {
      let index = Math.floor(Math.random() * bank.length);
      if (!indices.includes(index)) {
        indices.push(index);
        selected.push(bank[index]);
      }
    }
    return selected;
  }

  // Displays the selected questions in the HTML
  function displayQuestions(questions) {
    const quizList = document.querySelector(".quiz-list");
    quizList.innerHTML = ""; // Clear current questions
    correctAnswers = {}; // Reset correct answers

    questions.forEach((question, index) => {
      const li = document.createElement("li");
      li.className = "quiz-sublist";
      const questionHtml = `
          <span class="quiz-question">${question.question}</span>
          <ul class="quiz-answers">
            ${question.options
              .map(
                (option, oIndex) => `
              <li>
                <input type="radio" id="q${index}a${oIndex}" name="q${index}" value="${option}" />
                <label for="q${index}a${oIndex}">${option}</label>
              </li>
            `
              )
              .join("")}
          </ul>
        `;
      li.innerHTML = questionHtml;
      quizList.appendChild(li);

      // Update the correct answers object
      correctAnswers[`q${index}`] = question.answer;
    });
  }
});
