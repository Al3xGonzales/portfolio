document.addEventListener('DOMContentLoaded', function() {

var historyGrade = document.getElementById('historyGrade');
var biologyGrade = document.getElementById('biologyGrade');
var mathGrade = document.getElementById('mathGrade');

if (historyGrade) {
        historyGrade.textContent = window.globalFinalGrade_History + " / 5";
    }

if (biologyGrade) {
        biologyGrade.textContent = window.globalFinalGrade_Biology + " / 5";
    }


if (mathGrade) {
        mathGrade.textContent = window.globalFinalGrade_Math + " / 5";
    }

});