/* Andres Gallego 
CWID: 889001145
andresgallego@csu.fullerton.edu */

document.addEventListener("DOMContentLoaded", function () {
  const submitButton = document.querySelector("#submit-questions");
  const resetButton = document.querySelector("#reset-page");

  // Define the question bank
  const questionBank = [
    {
      question: "What is the basic unit of life?",
      options: ["Protein", "Gene", "Cell", "Tissue"],
      answer: "Cell",
    },
    {
      question: "Which molecule carries genetic information?",
      options: ["RNA", "Chromosome", "Protein", "DNA"],
      answer: "DNA",
    },
    {
      question: "During which process do plants convert sunlight into energy?",
      options: ["Respiration", "Photosynthesis", "Digestion", "Fermentation"],
      answer: "Photosynthesis",
    },
    {
      question: "What is the powerhouse of the cell?",
      options: ["Nucleus", "Ribosome", "Mitochondria", "Endoplasmic reticulum"],
      answer: "Mitochondria",
    },
    {
      question:
        "What term describes an organism's ability to maintain stable internal conditions?",
      options: ["Metabolism", "Homeostasis", "Evolution", "Adaptation"],
      answer: "Homeostasis",
    },

    {
      question: "Which blood cells are primarily responsible for immunity?",
      options: [
        "Red blood cells",
        "Platelets",
        "White blood cells",
        "Plasma cells",
      ],
      answer: "White blood cells",
    },
    {
      question:
        "What is the name of the process by which cells divide to produce new cells?",
      options: ["Meiosis", "Mitosis", "Photosynthesis", "Fission"],
      answer: "Mitosis",
    },
    {
      question:
        "Which vitamin is essential for the synthesis of blood clotting factors?",
      options: ["Vitamin A", "Vitamin B12", "Vitamin K", "Vitamin C"],
      answer: "Vitamin K",
    },
    {
      question: "What is the largest organ of the human body?",
      options: ["Heart", "Skin", "Liver", "Kidney"],
      answer: "Skin",
    },
    {
      question:
        "What group of organisms includes mushrooms, molds, and yeasts?",
      options: ["Bacteria", "Archaea", "Fungi", "Protozoa"],
      answer: "Fungi",
    },
    {
      question:
        "Which process describes the exchange of oxygen and carbon dioxide between living cells and their environment?",
      options: ["Respiration", "Photosynthesis", "Digestion", "Excretion"],
      answer: "Respiration",
    },
    {
      question: "Who developed the polio vaccine?",
      options: [
        "Louis Pasteur",
        "Alexander Fleming",
        "Jonas Salk",
        "Robert Koch",
      ],
      answer: "Jonas Salk",
    },
    {
      question:
        "What structure in the cell is responsible for organizing and moving chromosomes during cell division?",
      options: ["Nucleus", "Spindle fibers", "Golgi apparatus", "Lysosome"],
      answer: "Spindle fibers",
    },
    {
      question: "Which gland in the human body regulates metabolism?",
      options: [
        "Pancreas",
        "Adrenal gland",
        "Thyroid gland",
        "Pituitary gland",
      ],
      answer: "Thyroid gland",
    },
    {
      question:
        "What term describes the complete set of genetic material in an organism?",
      options: ["Genome", "Chromosome", "Gene pool", "Nucleotide"],
      answer: "Genome",
    },
  ];
  let correctAnswers = {}; // This will be dynamically filled based on generated questions

  generateQuestions(); // Initial question generation

  submitButton.addEventListener("click", function (event) {
    event.preventDefault();
    if (!allQuestionsAnswered()) {
      alert("Please answer all questions before submitting.");
      return;
    }

    calculateScoreAndProvideFeedback();
  });

  resetButton.addEventListener("click", function (event) {
    event.preventDefault();
    resetQuiz();
    generateQuestions(); // Regenerate questions on reset
  });

  function allQuestionsAnswered() {
    return Object.keys(correctAnswers).every(function (question) {
      return (
        document.querySelector(`input[name="${question}"]:checked`) !== null
      );
    });
  }

  function calculateScoreAndProvideFeedback() {
    let biologyScore = 0;
    Object.keys(correctAnswers).forEach(function (question) {
      const selectedAnswerElement = document.querySelector(
        `input[name="${question}"]:checked`
      );
      const listItem = selectedAnswerElement.closest("li"); // Get the closest list item
      const isCorrect =
        selectedAnswerElement.value === correctAnswers[question];

      if (isCorrect) {
        biologyScore++;
        listItem.classList.add("correct"); // Adds 'correct' class to the list item
      } else {
        listItem.classList.add("incorrect"); // Adds 'incorrect' class to the list item
      }
    });
    
    localStorage.setItem("biologyScore", biologyScore);
    window.globalFinalGrade_Biology = biologyScore;

    alert(
      `Your score is ${biologyScore} out of ${Object.keys(correctAnswers).length}`
    );
  }

  function resetQuiz() {
    document.querySelectorAll('input[type="radio"]').forEach(function (radio) {
      radio.checked = false;
      radio.parentNode.classList.remove("correct", "incorrect");
      localStorage.setItem("biologyScore", 0);
      window.globalFinalGrade_Biology = 0;
    });
  }

  // Generates a specified number of random questions and displays them
  function generateQuestions() {
    const selectedQuestions = selectRandomQuestions(questionBank, 5); // Adjust the number as necessary
    displayQuestions(selectedQuestions);
  }

  // Selects N random questions from the bank
  function selectRandomQuestions(bank, number) {
    let selected = [];
    let indices = [];
    while (selected.length < number) {
      let index = Math.floor(Math.random() * bank.length);
      if (!indices.includes(index)) {
        indices.push(index);
        selected.push(bank[index]);
      }
    }
    return selected;
  }

  // Displays the selected questions in the HTML
  function displayQuestions(questions) {
    const quizList = document.querySelector(".quiz-list");
    quizList.innerHTML = ""; // Clear current questions
    correctAnswers = {}; // Reset correct answers

    questions.forEach((question, index) => {
      const li = document.createElement("li");
      li.className = "quiz-sublist";
      const questionHtml = `
            <span class="quiz-question">${question.question}</span>
            <ul class="quiz-answers">
              ${question.options
                .map(
                  (option, oIndex) => `
                <li>
                  <input type="radio" id="q${index}a${oIndex}" name="q${index}" value="${option}" />
                  <label for="q${index}a${oIndex}">${option}</label>
                </li>
              `
                )
                .join("")}
            </ul>
          `;
      li.innerHTML = questionHtml;
      quizList.appendChild(li);

      // Update the correct answers object
      correctAnswers[`q${index}`] = question.answer;
    });
  }
});
