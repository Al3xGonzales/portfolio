/* Andres Gallego 
CWID: 889001145
andresgallego@csu.fullerton.edu */

document
  .getElementById("registrationForm")
  .addEventListener("submit", function (event) {
    event.preventDefault();

    // Retrieve user input
    const username = document.getElementById("username").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    // Construct a user object. In a real application, consider hashing the password.
    const user = { username, email, password };

    // Attempt to retrieve existing users from localStorage, or initialize an empty array if none exist.
    const users = JSON.parse(localStorage.getItem("users")) || [];

    // Check if the username or email already exists
    const userExists = users.some(
      (u) => u.username === username || u.email === email
    );

    if (userExists) {
      alert(
        "A user with the given username or email already exists. Please choose a different one."
      );
      return;
    }

    // Add the new user to the array of users and save it back to localStorage.
    users.push(user);
    localStorage.setItem("users", JSON.stringify(users));

    // Redirect to login page (index.html)
    window.location.href = "index.html";
  });
