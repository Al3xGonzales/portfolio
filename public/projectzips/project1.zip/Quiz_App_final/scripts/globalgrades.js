document.addEventListener('DOMContentLoaded', function() {
    
    window.globalFinalGrade_Math = localStorage.getItem('mathScore') || "N/A";
    window.globalFinalGrade_History = localStorage.getItem('historyScore') || "N/A";
    window.globalFinalGrade_Biology = localStorage.getItem('biologyScore') || "N/A";
});