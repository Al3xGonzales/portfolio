/* Name: Alexandru Gonzales
    CWID: 886202159
    Email: alexandrugonzales@csu.fullerton.edu
*/
document.addEventListener('DOMContentLoaded', function() {
    const quizTitle = document.querySelector('h1');
    const submissionButton = document.querySelector('.submit-btn');
    const resetButton = document.querySelector('.reset-btn')
    const dashboardButton = document.querySelector('#dashboard-btn');
    const finalGrade = document.getElementById('result');
    const answerBank = ['b', 'd', 'c', 'a', 'c'];
    let quizSubmitted = localStorage.getItem('quizSubmitted') === 'true';
    let mathScore = localStorage.getItem('mathScore');
    
    function reset() {
        localStorage.removeItem('quizSubmitted');
        localStorage.removeItem('mathScore');
        quizTitle.innerHTML = "Math Quiz";
        finalGrade.innerHTML = "";
        window.globalFinalGrade_Math = null;
    }

    if ((quizSubmitted == true) && (mathScore !== null) && (document.title == "math_quiz.html")) {
        quizTitle.innerHTML = "Math Quiz (SUBMITTED)";
        finalGrade.innerHTML = `Your final score is ${mathScore}/5`;
        window.globalFinalGrade_Math = mathScore;
    }

    dashboardButton.addEventListener("click", function(event) {
        if (quizSubmitted == false) {
            alert("You cannot leave the page untill you've submitted the quiz");
            event.preventDefault();
        }
    });

    submissionButton.addEventListener('click', function() {
        if (quizSubmitted == false) {
        mathScore = 0;
        for (let i = 1; i <= 5; i++) {
            const userAnswer = document.querySelector(`input[name="q${i}"]:checked`)?.value;
            if (userAnswer === answerBank[i - 1]) {
                mathScore += 1;
            }
        }
        quizSubmitted = true;
        quizTitle.innerHTML = "Math Quiz (SUBMITTED)";
        finalGrade.innerHTML = `Your final score is ${mathScore}/5`;
        localStorage.setItem('quizSubmitted', 'true');
        localStorage.setItem('mathScore', mathScore.toString());
        window.globalFinalGrade_Math = mathScore;
        } else {
            alert(`This quiz has already been submitted and graded with a score of ${mathScore}/5`);
        }
    });

    resetButton.addEventListener("click", function(event) {
        reset();
    });

});